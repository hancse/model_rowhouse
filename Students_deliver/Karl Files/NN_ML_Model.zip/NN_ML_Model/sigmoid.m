function out = sigmoid(inp)
  % this function simply calculates the sigmoid function for every entry in
  % the input matrix inp and returns the result in the matrix out

  out = 1 ./ (1 + exp(-inp));
end
